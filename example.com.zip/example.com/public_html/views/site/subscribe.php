<?php

use yii\widgets\LinkPager;



$this->title = "Выпуски рассылки";

$this->registerMetaTag([
    'name' => 'description',
    'content' => 'Все выпуски рассылки от Андрея Слюсара.',
]);


$this->registerMetaTag([
    'name' => 'keywords',
    'content' => 'рассылка слюсар, выпуски рассылки, выпуски рассылки слюсар, выпуски рассылки андрей слюсар',
]);
?>



<div id="left">
    <div id="other">

	<h1>Выпуски рассылки</h1>
        <?php include "likes.php"; ?>
	<p class="center">
		<img src="/web/images/subscribe.png" alt="Выпуски рассылки" />
	</p>
        <div id="minicourses">
	<p>В этом разделе я решил выложить все выпуски своей рассылки. Раньше их видели только мои подписчики, но письма очень часто теряются, не доходят, случайно удаляются. В результате, человек просто не получил очень важный для него выпуск.</p>
	<p>Чтобы исправить эту проблему, я просто буду выкладывать в этом разделе все новые выпуски своей рассылки. Разумеется, узнавать о выходе новых выпусков будут только мои подписчики. Поэтому если Вы не хотите постоянно проверять появились ли новые выпуски или нет, просто подпишитесь на мою рассылку.</p>
	<p>Чтобы стать моим подписчиком, достаточно выбрать любой из мини-курсов, которые Вас заинтересует. Если Вы заинтересовали оба, то можете подписаться на оба, это не запрещается.</p>
	<p>Что такое мини-курс? Мини-курс - это бесплатная серия секретных видеоуроков, которые недоступны остальным пользователям. Эти видеоуроки направлены на то, чтобы Вы получили максимум знаний по выбранной теме курса.</p>
	<p>Итак, чтобы стать моим подписчиком и получить секретные видеоуроки, заполните форму рядом с одним из представленных курсов.</p>		
	</div>
            <?php foreach($minicourses as $course) { ?>
            <div class="<?php if ($course->default == 1) { ?>show<?php } else { ?>hide<?php } ?>">
                <h4><?=$course->title?></h4>
                <img src="<?=$course->img?>" alt="<?=$course->title?>" />
                <?php include "form_subscribe.php"; ?>
            </div>
            <?php } ?>
			
     
   </div>
 </div>







<?php foreach ($posts as $post) include "intro_post.php"; ?>
	

<div id="pagination">
    <?=LinkPager::widget([
                'pagination' => $pagination,
                'firstPageLabel' => 'В начало',
                'lastPageLabel' => 'В конец',
                'prevPageLabel' => '&laquo;',
            ])
        
        ?>		
	<span>Страница <?=$active_page?> из <?=$count_pages?></span>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;В начало&nbsp; &laquo; &nbsp;
										1&nbsp;
							<a href="/?page=2">2</a>&nbsp;
							<a href="/?page=3">3</a>&nbsp;
							<a href="/?page=4">4</a>&nbsp;
							<a href="/?page=5">5</a>&nbsp;
							<a href="/?page=6">6</a>&nbsp;
							<a href="/?page=7">7</a>&nbsp;
							<a href="/?page=8">8</a>&nbsp;
							<a href="/?page=9">9</a>&nbsp;
							<a href="/?page=2">&raquo;</a>&nbsp;
				<a href="/?page=9">В конец &raquo;</a>
        <div class="clear"></div>
</div>

