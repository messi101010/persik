<?php
use yii\widgets\LinkPager;

$this->title = "Личный блог Андрея Слюсара";

$this->registerMetaTag([
    'name' => 'description',
    'content' => 'Личный блог Андрея Слюсара и его выпуски рассылки',
]);


$this->registerMetaTag([
    'name' => 'keywords',
    'content' => 'андрей слюсар, блог андрей слюсар, рассылка андрей слюсар',
]);

?>



<?php

    foreach($posts as $post) { include "intro_post.php"; }
    
?>




	
	<div id="pagination">
            
            <?= LinkPager::widget([
                'pagination' => $pagination,
                'firstPageLabel' => 'В начало',
                'lastPageLabel' => 'В конец',
                'prevPageLabel' => '&laquo;',
            ])
        
        ?>
		
	
                <div id="pagination">
                    <span>Страница <?=$active_page?> из <?=$count_pages?></span>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;В начало&nbsp; &laquo; &nbsp;
										1&nbsp;
							<a href="/?page=2">2</a>&nbsp;
							<a href="/?page=3">3</a>&nbsp;
							<a href="/?page=4">4</a>&nbsp;
							<a href="/?page=5">5</a>&nbsp;
							<a href="/?page=6">6</a>&nbsp;
							<a href="/?page=7">7</a>&nbsp;
							<a href="/?page=8">8</a>&nbsp;
							<a href="/?page=9">9</a>&nbsp;
							<a href="/?page=2">&raquo;</a>&nbsp;
				<a href="/?page=9">В конец &raquo;</a>
		</div>
                
                
                
                
                
                
                
                
                
                
                
		<div class="clear"></div>
	</div>
