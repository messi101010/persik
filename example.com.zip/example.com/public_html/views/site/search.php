<?php

use yii\widgets\LinkPager;

$this->title = "Поиск $q";

$this->registerMetaTag([
    'name' => 'description',
    'content' => "Поиск: $q.",
]);


$this->registerMetaTag([
    'name' => 'keywords',
    'content' => $q,
]);
?>

<?php if ($q == "") { ?>
    <h2>Вы задали пустой поисковый запрос!</h2>
<?php } else { ?>
<h2>Результаты поиска: <?=$q?></h2>

<?php if (!$posts) { ?>
     <p>Ничего не найдено</p>
<?php } else { ?>
     <?php foreach ($posts as $post) include "intro_post.php"; ?>

<br />
<hr />
<div id="pagination">
            
            <?= LinkPager::widget([
                'pagination' => $pagination,
                'firstPageLabel' => 'В начало',
                'lastPageLabel' => 'В конец',
                'prevPageLabel' => '&laquo;',
            ])
        
        ?>
		
	
                <div id="pagination">
                    <span>Страница <?=$active_page?> из <?=$count_pages?></span>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;В начало&nbsp; &laquo; &nbsp;
										1&nbsp;
							<a href="/?page=2">2</a>&nbsp;
							<a href="/?page=3">3</a>&nbsp;
							<a href="/?page=4">4</a>&nbsp;
							<a href="/?page=5">5</a>&nbsp;
							<a href="/?page=6">6</a>&nbsp;
							<a href="/?page=7">7</a>&nbsp;
							<a href="/?page=8">8</a>&nbsp;
							<a href="/?page=9">9</a>&nbsp;
							<a href="/?page=2">&raquo;</a>&nbsp;
				<a href="/?page=9">В конец &raquo;</a>
		</div>
                
</div>
    <?php } ?>
<?php } ?>