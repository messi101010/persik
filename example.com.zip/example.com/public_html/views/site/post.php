<?php
$this->title = $post->title;

$this->registerMetaTag([
    'name' => 'description',
    'content' => $post->meta_desc,
]);


$this->registerMetaTag([
    'name' => 'keywords',
    'content' => $post->meta_key,
]);
?>

<div id="left">
    <div id="other">
            <div class="post">
                <h4><?php if ($post->is_release) { ?>Выпуск №<?=$post->number?>. <?php } ?></h4><h1><?=$post->title?></h1>
		<div class="img">
			<img src="<?=$post->img?>" alt="<?=$post->title?>" />
		</div>
		<div class="text">
			<?=$post->full_text?>		
                </div>
		<div class="more">
			<a href="/multilanguage.html">ЧИТАТЬ ПОЛНОСТЬЮ &gt;</a>
		</div>
		<div class="info">
			<div class="date"><?=$post->date?></div>
			<div class="hits">
				<img src="/web/images/hits.png" alt="" />Просмотров: <?=$post->hits?>			</div>
			<div class="clear"></div>
		</div>
          </div>
    </div>
</div>