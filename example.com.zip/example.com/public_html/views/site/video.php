<?php
$this->title = "Видеокурсы от Андрея Слюсара";

$this->registerMetaTag([
    'name' => 'description',
    'content' => 'Информация обо всех обучающих Видеокурсах от Андрея Слюсара.',
]);


$this->registerMetaTag([
    'name' => 'keywords',
    'content' => 'видеокурсы слюсар, видеокурсы андрей слюсар, андрей николаевич слюсар',
]);
?>

<div id="left">
    <div id="other">
       
        <h1>Видеокурсы от Слюсара Андрея</h1>
         <?php include "likes.php"; ?>
	<p>Есть несколько вариантов обучения созданию сайтов. Давайте их разберём:</p>
        
        
        
        <?php
        $number = 0;
        foreach($courses as $course) { $number++;  ?>
                   <hr />
                    <div class="course">
		<h3><?=$number?>. <?=$course->title?></h3>
		<div class="course_table">
			<div>
				<div>
					<img src="<?=$course->img?>" alt="<?=$course->title?>" />
				</div>
                            
                            <?php if (!$course->did) { ?>
                            
				<div class="course_order">
											<p>ЦЕНА: <span><?=$course->price?> руб.</span></p>
						<div class="order">
							<a href="<?=$course->order?>">ЗАКАЗАТЬ</a>
						</div>
						<div class="more">
							<a href="<?=$course->title?>">ПОДРОБНЕЕ</a>
						</div>
				</div>
                            
                            <?php } else { include "form_subscribe.php"; } ?>
                            
			</div>
		</div>
		<div class="clear"></div>
		<?=$course->description?>
        </div>
        <?php } ?>
        	
    </div>
</div>
  


       
        
        
       