<div class="post">
				<h1>Редизайн блога Blog.MySlyusar.ru</h1>
		<div class="img">
			<img src="https://blog.myrusakov.ru/images/posts/redesign.png" alt="<?=$post->title?>" />
		</div>
		<div class="text">
			<?=$post->intro_text?>		</div>
		<div class="more">
			<a href="<?=$post->link?>">ЧИТАТЬ ПОЛНОСТЬЮ &gt;</a>
		</div>
		<div class="info">
			<div class="date"><?=$post->date?></div>
			<div class="hits">
				<img src="/web/images/hits.png" alt="" />Просмотров: <?=$post->hits?>			</div>
			<div class="clear"></div>
		</div>
	</div>

	<div class="post">
		<h4> <?php if($post->is_release) { ?>Выпуск №<?=$post->number?>.</h4>		<h1><?php } ?><?=$post->title?></h1>
		<div class="img">
			<img src="https://blog.myrusakov.ru/images/posts/multilanguage.png" alt="<?=$post->title?>" />
		</div>
		<div class="text">
			<?=$post->intro_text?>	
                </div>
		<div class="more">
			<a href="<?=$post->link?>">ЧИТАТЬ ПОЛНОСТЬЮ &gt;</a>
		</div>
		<div class="info">
			<div class="date"><?=$post->date?></div>
			<div class="hits">
				<img src="/web/images/hits.png" alt="" />Просмотров: <?=$post->hits?>			</div>
			<div class="clear"></div>
		</div>
	</div>
	<div class="post">
		<h4> <?php if($post->is_release) { ?>Выпуск №<?=$post->number?>Выпуск №<?=$post->number?>.</h4>		<h1><?php } ?><?=$post->title?></h1>
		<div class="img">
			<img src="https://blog.myrusakov.ru/images/posts/https.png" alt="<?=$post->title?>" />
		</div>
		<div class="text">
			<?=$post->intro_text?>			</div>
		<div class="more">
			<a href="<?=$post->link?>">ЧИТАТЬ ПОЛНОСТЬЮ &gt;</a>
		</div>
		<div class="info">
			<div class="date"><?=$post->date?></div>
			<div class="hits">
				<img src="/web/images/hits.png" alt="" />Просмотров: <?=$post->hits?>			</div>
			<div class="clear"></div>
		</div>
	</div>
	<div class="post">
		<h4> <?php if($post->is_release) { ?>Выпуск №<?=$post->number?>.</h4>		<h1><?php } ?><?=$post->title?></h1>
		<div class="img">
			<img src="https://blog.myrusakov.ru/images/posts/api-vk.png" alt="<?=$post->title?>" />
		</div>
		<div class="text">
			<?=$post->intro_text?>		</div>
		<div class="more">
			<a href="<?=$post->link?>">ЧИТАТЬ ПОЛНОСТЬЮ &gt;</a>
		</div>
		<div class="info">
			<div class="date"><?=$post->date?></div>
			<div class="hits">
				<img src="/web/images/hits.png" alt="" />Просмотров: <?=$post->hits?>			</div>
			<div class="clear"></div>
		</div>
	</div>
	<div class="post">
		<h4> <?php if($post->is_release) { ?>Выпуск №<?=$post->number?>.</h4>		<h1><?php } ?><?=$post->title?></h1>
		<div class="img">
			<img src="https://blog.myrusakov.ru/images/posts/fraud.png" alt="<?=$post->title?>" />
		</div>
		<div class="text">
			<?=$post->intro_text?>		</div>
		<div class="more">
			<a href="<?=$post->link?>">ЧИТАТЬ ПОЛНОСТЬЮ &gt;</a>
		</div>
		<div class="info">
			<div class="date"><?=$post->date?></div>
			<div class="hits">
				<img src="/web/images/hits.png" alt="" />Просмотров: <?=$post->hits?>				</div>
			<div class="clear"></div>
		</div>
	</div>
	<div class="post">
		<h4> <?php if($post->is_release) { ?>Выпуск №<?=$post->number?>.</h4>		<h1><?php } ?><?=$post->title?></h1>
		<div class="img">
			<img src="https://blog.myrusakov.ru/images/posts/plan.png" alt="<?=$post->title?>" />
		</div>
		<div class="text">
			<?=$post->intro_text?>		</div>
		<div class="more">
			<a href="<?=$post->link?>">ЧИТАТЬ ПОЛНОСТЬЮ &gt;</a>
		</div>
		<div class="info">
			<div class="date"><?=$post->date?></div>
			<div class="hits">
				<img src="/web/images/hits.png" alt="" />Просмотров: <?=$post->hits?>				</div>
			<div class="clear"></div>
		</div>
	</div>
	<div class="post">
		<h4> <?php if($post->is_release) { ?>Выпуск №<?=$post->number?>.</h4>		<h1><?php } ?><?=$post->title?></h1>
		<div class="img">
			<img src="https://blog.myrusakov.ru/images/posts/content.png" alt="<?=$post->title?>" />
		</div>
		<div class="text">
			<?=$post->intro_text?>			</div>
		<div class="more">
			<a href="<?=$post->link?>">ЧИТАТЬ ПОЛНОСТЬЮ &gt;</a>
		</div>
		<div class="info">
			<div class="date"><?=$post->date?></div>
			<div class="hits">
				<img src="/web/images/hits.png" alt="" />Просмотров: <?=$post->hits?>				</div>
			<div class="clear"></div>
		</div>
	</div>
	