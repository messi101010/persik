<?php
namespace app\components;

use yii\base\Widget;
use yii\helpers\Html;
use app\models\Posts;

class PostOthers extends Widget {
    
    public $id;
    
    public function run() {
        $posts = Posts::find()->where(['hide' => 0])->limit(5)->where(['not', ['id' => $this->id]])->orderBy("rand()")->all();
        
        
        $divs = "";
        
        foreach ($posts as $post){
            $img = Html::tag('img',  null, ['src' => $post->img, 'alt' => $post->title]);
            $div_1 = Html::tag('div', $img);
            $a_p = Html::tag('a','&laquo;'.$post->title.'&raquo;', ['href' => $post->link]);
            $div_2 = Html::tag('p', $a_p);
            $divs = Html::tag('div', $div_1.$div_2);
        }
        return Html::tag('div', $divs, ['id' => 'courses'] );
    }
    
    
     
    
    
    
}
?>