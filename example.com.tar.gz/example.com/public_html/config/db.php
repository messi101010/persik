<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=blog',
    'username' => 'root',
    'password' => '123',
    'charset' => 'utf8',
    'tablePrefix' => 'bl_',
];
