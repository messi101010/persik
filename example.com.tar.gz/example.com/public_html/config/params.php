<?php

return [
    'adminEmail' => 'slyusar94@mail.ru',
    'dir_tmpl' => '/views/site/',
];
