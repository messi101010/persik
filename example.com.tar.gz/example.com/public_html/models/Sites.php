<?php
namespace app\models;

use yii\db\ActiveRecord;

class Sites extends ActiveRecord {
    
}
?>