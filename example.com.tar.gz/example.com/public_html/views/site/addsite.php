<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;


$this->title = "Добавить сайт";

$this->registerMetaTag([
    'name' => 'description',
    'content' => 'Добавить сайт на блог Андрея Слюсара.',
]);


$this->registerMetaTag([
    'name' => 'keywords',
    'content' => 'добавить сайт, добавить сайт блог, добавить сайт блог андрей слюсар',
]);
?>



<div id="left">
    <div id="other">
<h2>Заполните форму</h2>
<?php if ($success) { ?>
     <p>Ваш сайт успешно добавлен!</p>
<?php } ?>
<?php if ($error) { ?>
     <p class="red">Произошла ошибка при добавлении сайта!</p>
<?php } ?>
     
     
<?php $form = ActiveForm::begin(); ?>
    <input type="hidden" name="func" value="addsite">
    Адрес сайта: <?= $form->field($model, 'address')->label(''); ?>
    Описание (не более 255 символов) <?= $form->field($model, 'description')->textarea(['rows' => '6'])->label(''); ?>
    <?= Html::submitButton('Добавить сайт', ['class' => 'bg_center'])?>
<?php ActiveForm::end(); ?>
    </div>
</div>