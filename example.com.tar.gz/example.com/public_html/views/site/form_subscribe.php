<div class="course_order">
 <p>ЗАПОЛНИТЕ ФОРМУ</p>
 <form name="subscribe_<?=$course->id?>" method="post" action="https://blog.myrusakov.ru/subscribe.html?utm_source=Blog.MyRusakov.ru&amp;utm_campaign=freeim2" onsubmit="return SR_submit(this)">
			<div>
			        <input name="name" placeholder="Ваше имя" type="text">
			</div>
			<div>
				<input name="email" placeholder="Ваш email" type="text">
			</div>
			<div>
				<input name="delivery_id" value="<?=$course->did?>" type="hidden">
				<input name="subscribe_freeim2" value="ПОЛУЧИТЬ ВИДЕОКУРС" type="submit">
			</div>
 </form>
</div>
